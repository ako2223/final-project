import React from 'react'
import style from './Footer.module.scss'

function Footer() {
    return (
        <div>Footer placeholder</div>
    )
}

export default Footer
