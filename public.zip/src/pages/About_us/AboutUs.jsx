import React from 'react'

function AboutUs() {
    return (
        <div>About us placeholder</div>
    )
}

export default AboutUs
