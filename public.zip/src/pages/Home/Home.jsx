import React from 'react'
import style from './Home.module.scss'

function Home() {
    return (
        <div>Home placeholder</div>
    )
}

export default Home
